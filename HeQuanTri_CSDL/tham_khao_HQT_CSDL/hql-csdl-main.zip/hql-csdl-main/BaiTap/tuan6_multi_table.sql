USE AdventureWorks2008R2
go

-- 9) Viết lại các câu 5,6,7,8 bằng Multi-statement table valued function


-- 10)Viết hàm tên SalaryOfEmp trả về kết quả là bảng lương của nhân viên, với tham
-- số vào là @MaNV (giá trị của [BusinessEntityID]), thông tin gồm
-- BusinessEntityID, FName, LName, Salary (giá trị của cột Rate).