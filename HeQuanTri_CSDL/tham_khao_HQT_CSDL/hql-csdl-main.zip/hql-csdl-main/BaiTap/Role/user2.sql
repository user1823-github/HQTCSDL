USE AdventureWorks2008R2
GO

-- Kiểm tra cấp quyền trên sales.SalesOrderHeader
SELECT *
FROM sales.SalesOrderHeader
GO

-- Kiểm tra cấp quyền select trên HumanResources.Employee
SELECT *
FROM HumanResources.Employee
GO

-- 7.a) 
SELECT *
FROM HumanResources.Employee
GO